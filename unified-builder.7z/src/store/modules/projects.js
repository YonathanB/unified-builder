import * as types from '../mutation-types'
import service from '../../services/ajax'

import {K_layout, K_project} from "../../model/Models";

//TODO move to utils
var buildHierarchy = function (arry) {

  var roots = [], children = {};

  // find the top level nodes and hash the children based on parent
  for (var i = 0, len = arry.length; i < len; ++i) {
    var item = arry[i],
      p = item.parent_id,
      target = !p ? roots : (children[p] || (children[p] = []));

    target.push({value: item});
  }

  // function to recursively build the tree
  var findChildren = function (parent) {
    if (children[parent.value.id]) {
      parent.children = children[parent.value.id];
      for (var i = 0, len = parent.children.length; i < len; ++i) {
        findChildren(parent.children[i]);
      }
    }
  };

  // enumerate through to handle the case where there are multiple roots
  for (var i = 0, len = roots.length; i < len; ++i) {
    findChildren(roots[i]);
  }

  return roots;
}


const state = {
  appIsLoading: false,
  projects: {
    byId: {},
    all: []
  },
  spaces: {
    byId: {},
    all: [],
  },
  layouts: {
    byId: {},
    all: []
  },
  devices: {
    byId: {},
    all: []
  },
  events: {
    byId: {},
    all: []
  },
  macros: {
    byId: {},
    all: []
  },
  gateways: {
    byId: {},
    all: []
  },
}

// getters
const getters = {
  allProjects: state => state.projects.all.map(projectId => state.projects.byId[projectId]),
  projectsFilteredByName: (state, getters) => {
    return (str) => {
      if (!str) return getters.allProjects;
      return getters.allProjects.filter(function (project) {
        return project.name.toUpperCase().indexOf(str.toUpperCase()) !== -1;
      })
    }
  },
  allSpaces: state => state.spaces.all.map(spaceId => state.spaces.byId[spaceId]),
  spacesForProjects: (state, getters) => { // TODO - rename
    return (projectId) => getters.allSpaces.filter(space => space.value.project_id === projectId)
  },
  allLayouts: state => state.layouts.all.map(layoutId => state.layouts.byId[layoutId]),
  layoutsInSpace: (state, getters) => {
    return (spaceId) => getters.allLayouts.filter(layout => layout.space_id === spaceId)
  },
  allDevices: state => state.devices.all.map(deviceId => state.devices.byId[deviceId]),
  devicesInSpace: (state, getters) => {
    return (spaceId) => getters.allDevices.filter(device => device.space_id === spaceId)
  },
  allEvents: state => state.events.all.map(eventId => state.events.byId[eventId]),
  eventsInSpace: (state, getters) => {
    return (spaceId) => getters.allEvents.filter(event => event.space_id === spaceId)
  },
  allMacros: state => state.macros.all.map(macroId => state.macros.byId[macroId]),
  macrosInSpace: (state, getters) => {
    return (spaceId) => getters.allMacros.filter(macro => macro.space_id === spaceId)
  },

  allGateways: state => state.gateways.all.map(gatewayId => state.gateways.byId[gatewayId]),
  gatewaysInSpace: (state, getters) => {
    return (spaceId) => getters.allGateways.filter(gateway => gateway.space_id === spaceId)
  },

}

// actions
const actions = {
  getAllProjects(store) {
    store.commit(types.LOADING_INIT_DATA, true)
    service.getAllProjects().then((response) => {
      const projects = [];
      if (response) {
        let promises = response.map(projectData => {
          let project = new K_project(projectData);
          projects.push(project);
          return project.getSpaces()
        });
        Promise.all(promises).then((response) =>  {
          store.commit(types.INSERT_PROJECTS, projects)
          store.commit(types.LOADING_INIT_DATA, false)
        })
      }
      else if (error)
        store.commit(types.INVALID_TOKEN, {error})
    })
  },
  getSpaceData(store, space) {
    store.commit(types.SET_ACTIVE_SPACE, space.id)
    store.commit(types.LOADING_LAYOUT, true)
    space.getLayouts().then((layouts) => {
      const promises = [];
      layouts.map(layout => {
        promises.push(layout.getMacros())
        promises.push(layout.getEvents())
      })
      Promise.all(promises).then((response) => store.commit(types.INSERT_LAYOUTS, response))
    })
    space.getGateways();
    space.getDevices().then((devices) => {
      Promise.all(
        devices.map(device => device.getDrivers())
      ).then(
        (response) => {
          space._devicesAnalysis()
          store.commit(types.DEVICES_SPACES_LOADED, devices)
        })
    })
  },
  onTokenUpdated(store){
    if(store.getters.allProjects.length === 0)
      store.dispatch('getAllProjects');
  },

  getLayoutDataForAnalysis(store, space) {
    let promises = [];
    promises.push(service.getDevicesInSpace(space, (devices, error) => {
      if (devices) {
        store.commit(types.DEVICES_SPACES_LOADED, {devices, space})
       let promises = store.getters.devicesInSpace(space.id).map(device =>
          service.getDriversForDevice(device, (drivers) => {
            if(drivers)
              store.commit(types.DRIVERS_DEVICE_LOADED, {drivers, device})
          })
        )
        Promise.all(promises).then((response) =>{
          store.getters.layoutsInSpace(space.id).map(layout => layout._devicesAnalysis(store.getters.devicesInSpace(space.id)))
        })
      }
    }))
    promises.push(service.getEventsInSpace(space, (events, error) => {
      if (events)
        store.commit(types.EVENTS_SPACES_LOADED, {events, space})
    }))
    promises.push(service.getGatewaysInSpace(space, (gateways, error) => {
      if (gateways) {
        gateways.map(gatewayData => gatewayData.space_id = space.id)
        store.commit(types.GATEWAYS_SPACES_LOADED, {gateways, space})
      }
    }))
    promises.push(service.getMacrosInSpace(space, (macros, error) => {
      if (macros)
        store.commit(types.MACROS_SPACES_LOADED, {macros, space})
    }))

    Promise.all(promises).then((response) => {


      store.getters.layoutsInSpace(space.id).map(
        layout => {
          layout._gatewaysAnalysis(store.getters.gatewaysInSpace(space.id));
          layout._eventsAnalysis(store.getters.eventsInSpace(space.id));
          layout._macrosAnalysis(store.getters.macrosInSpace(space.id));
        })
    })
  },
}


var insertInStore = function (storeProperty, data) {
  //TODO check with getters
  data.map(dataToInsert => {
    state[storeProperty].byId[dataToInsert.id] = dataToInsert;
    if (state[storeProperty].all.indexOf(dataToInsert.id) === -1)
      state[storeProperty].all.push(dataToInsert.id)
  })

}


// mutations
const mutations = {
  [types.LOADING_INIT_DATA](state, value) {
    state.appIsLoading = value;
  },
  [types.LOADING_LAYOUT](state, value) {
    state.layoutIsLoading = value;
  },
  [types.INSERT_PROJECTS](state, projects) {
    insertInStore('projects', projects)
    projects.map(project => insertInStore('spaces', project.__spaces))
  },

  [types.SET_ACTIVE_SPACE](state, spaceId) {
    state.activeState = spaceId;
  },
  [types.INSERT_LAYOUTS](state, layouts) {
    insertInStore('layouts', layouts)
  },

  [types.UPDATE_ANALYSIS](state, layouts) {
    console.log(layouts)
    // insertInStore('layouts', layouts)
  },


  [types.SPACES_LOADED](state, {spaces}) {
    spaces.map(spaceData => {
      state.spaces.byId[spaceData.value.id] = spaceData;
      if (state.spaces.all.indexOf(spaceData.value.id) === -1)
        state.spaces.all.push(spaceData.value.id)
    });
  },

  [types.DEVICES_SPACES_LOADED](state, devices) {
    insertInStore('devices', devices)
  },
  [types.EVENTS_SPACES_LOADED](state, {events, space}) {
    insertInStore('events', events)
  },
  [types.GATEWAYS_SPACES_LOADED](state, {gateways, space}) {
    insertInStore('gateways', gateways)
  },
  [types.MACROS_SPACES_LOADED](state, {macros, space}) {
    insertInStore('macros', macros)
  },
  [types.DRIVERS_DEVICE_LOADED](state, {drivers, device}) {
    state.devices.byId[device.id].__driver = drivers;
  }
}

export default {
  state,
  getters,
  actions,
  mutations
}
