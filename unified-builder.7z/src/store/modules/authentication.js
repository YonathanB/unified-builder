




import * as types from '../mutation-types'
import service from '../../services/ajax'

import {auth} from '../../utils/authentication'

const state = {
  token: null,
  authenticated: false
};

// getters
const getters = {
  getToken: state => state.token,
  isLoggedIn: state => state.authenticated
  };


// actions
const actions = {
  onTokenInValid ({ commit }) {
    console.log('invalid token')
      commit(types.UPDATE_AUTHENTICATE, false)
  },
  updateToken ({ commit, dispatch }, token) {
    commit(types.SET_TOKEN, token)
    commit(types.UPDATE_AUTHENTICATE, true)
    dispatch('onTokenUpdated')
  },

}

// mutations
const mutations = {
  [types.SET_TOKEN] (state, token ) {
    state.token = token;
  },
  [types.INVALID_TOKEN] (state) {
    state.authenticated = false
  },
  [types.UPDATE_AUTHENTICATE] (state, value) {
    state.authenticated = value
  }
}

export default {
  state,
  getters,
  actions,
  mutations
}

