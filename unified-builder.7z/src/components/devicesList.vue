<template>
<v-card class="pa-0" color="grey lighten-4">
   <v-toolbar flat dense color="blue lighten-1 " dark>
      <v-toolbar-title >Devices</v-toolbar-title>
   </v-toolbar>
  <!-- TODO v-resize="onResize"-->
   <v-card  color="grey lighten-4" style="height: calc(100vh - 80px)" flat class="scroll-y" >
      <v-list class="pa-0 devices-list" color="grey lighten-4" style=" background-color:#f5f5f5;">
         <template v-for="(device, i) in devices">
            <v-list-tile v-bind:key="i" @click="">
               <v-list-tile-content>
                  <v-list-tile-title style="font-size:13px">
                     <span :class="device.class">{{device.name}}</span>
                  </v-list-tile-title>
               </v-list-tile-content>
            </v-list-tile>
         </template>
      </v-list>
   </v-card>
</v-card>
</template>

<script>
export default {
    name: "krDevicesList",
  props: ['devices'],
}
</script>

<style scoped>

</style>
