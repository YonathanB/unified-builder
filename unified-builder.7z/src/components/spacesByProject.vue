<template>
  <li>
  <v-flex @click="getSpaceData(model.value)" align-content-center	 justify-start>
    <!--:class="{'selected': isSelected}">-->
  <!-->
  <v-icon v-if="isFolder">domain</v-icon>
  <span> {{ model.value.name }}</span>
  </v-flex>
  <ul  v-if="isFolder" >
  <kr-spaces  v-for="(space, index) in model.children"
  :key="index" :model="space" />
  </ul>
  </li>
</template>

<script>
export default {
  name: "kr-spaces",
  props: {
    model: Object
  },
  data: function () {
    return {
      open: false
    }
  },
  computed: {
    isFolder: function () {
      return this.model.children &&
        this.model.children.length
    }
    // isSelected: function (value) {
    //   return uniBuilderStore.state.currentSpace && uniBuilderStore.state.currentSpace.name === this.$props.model.value.name
    // }
  },
  methods: {
    getSpaceData: function (space) {
      this.$store.dispatch('getSpaceData', space)
    }
  }
}
</script>

<style scoped>

.k-space .item {
  cursor: pointer;
}

.k-space .bold {
  font-weight: bold;
}

ul.k-space {
  line-height: 2.5em;
  list-style-type: dot;
  justify-content: start
}

.k-space li {
  padding-left: 1em;
  display: flex;
  flex-direction: column;
  width: 100%;
  cursor: pointer;
  background: #e8e8e8;

}

.k-space li div {
  padding-left: 2.5em;
}

.k-space li div:hover {
  background: gainsboro
}

</style>
