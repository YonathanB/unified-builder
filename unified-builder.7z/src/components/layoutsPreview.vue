<template>
<v-card color="grey lighten-3" class="layouts-content pa-0" >
   <!--<div v-if="isEmptyLayout" style="display: flex; justify-content: center;  align-items: center; height: 100%;">-->
      <!--<h3>That space doesn't have any layout to show</h3>-->
   <!--</div>-->
  <v-toolbar color="blue lighten-1 " dark dense flat tabs>
  <v-toolbar-title>Layouts</v-toolbar-title>
      <v-tabs  slot="extension" grow light v-model="activeTab" >
         <v-tabs-slider color="blue darken-1"></v-tabs-slider>
         <v-tab
           v-for="(layout, i) in layouts"
           :key="i"
           :href="'#'+i" >
            {{ layout.name }}
         </v-tab>
      </v-tabs>
     </v-toolbar>
      <v-tabs-items v-model="activeTab">
         <v-tab-item
           v-for="(layout, i) in layouts"
           :key="i"
           :id="''+i">
            <v-container class="layout scroll-y"  style="height: calc(100vh - 280px); max-height: 460px;  width:auto">
               <div id="#preview" :style="layout.display.imgPrvw">
                  <div class="content" :style="layout.display.imgOverlay">
                     <div v-for="content in layout.display.imgContent" :style="content.styles">
                        <span v-if="content.text" :style="content.text.styles">{{content.text.text}}</span>
                     </div>
                  </div>
               </div>
            </v-container>
           <kr-layout-analysis :v-if="layout.__analysis" :analysis-data="layout.__analysis"/>

         </v-tab-item>
      </v-tabs-items>
</v-card>
</template>

<script>
  import { mapGetters, mapActions } from 'vuex'
  import krLayoutAnalysis from './layoutAnalysis'
export default {
    name: "krLayoutsPreview",
  props: ['layouts'],
  // computed:
components: {krLayoutAnalysis},
  data:() =>({
    activeTab: "0"
  })
}
</script>

<style scoped>


</style>
