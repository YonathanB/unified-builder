<template>
   <div id="app">
        <v-app>

           <v-snackbar :timeout="timeoutSnackLogin" :top="true" v-model="isTokenExpired">
                {{ LoginSnackBarText }}
                <v-btn flat color="pink" @click.native="K_ControlLogin()">Login</v-btn>
           </v-snackbar>
            <v-container fluid grid-list-md class="grey lighten-3 pa-0">
              <v-layout row wrap>
                <v-flex  d-flex  xs6  sm3  class="pa-0"><kr-project-list /></v-flex>
                <v-flex  xs12 sm7 order-xs3 order-sm2 class="pa-0"><kr-layouts-preview  :layouts="layouts"/></v-flex>
                <v-flex xs6  sm2 order-xs2 class="pa-0"><kr-devices-list :devices="devices"/></v-flex>
              </v-layout>
            </v-container>

            <v-footer app></v-footer>
        </v-app>

    </div>
</template>

<script>

import * as types from './store/mutation-types'
import { auth } from './utils/authentication';
import krProjectList from './components/projectsList'
import krLayoutsPreview from './components/layoutsPreview'
import krDevicesList from './components/devicesList'
import krLayoutAnalysis from './components/layoutAnalysis'

export default {
  name: 'app',
  data: () => ({
    timeoutSnackLogin: 10000000,
    LoginSnackBarText: 'Your login session has expired'
  }),
  components: {krProjectList, krLayoutsPreview, krDevicesList, krLayoutAnalysis},
  watch: {},
  computed: {
    isTokenExpired: function () {  return !this.$store.getters.isLoggedIn  },
    selectedSpace: function(){  return this.$store.getters.getSelectedSpace },
    layouts: function(){ return this.$store.getters.layoutsInSpace(this.selectedSpace) },
    devices: function(){ return this.$store.getters.devicesInSpace(this.selectedSpace) }
  },
  created(){
    this.$store.dispatch('getAllProjects')
  },
  beforeMount: function () {

  },
  mounted: function () {

  },
  methods: {
    K_ControlLogin: function () {
      var _that = this;
      auth.login({
        callback: function (tokenFromPopup) {
          _that.$store.dispatch('updateToken', tokenFromPopup)
        }
        });

    }
  }
}
</script>

<style>

</style>
